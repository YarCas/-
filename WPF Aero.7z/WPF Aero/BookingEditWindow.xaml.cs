﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class BookingEditWindow : Window
    {
        private Booking _booking;

        public BookingEditWindow(Booking booking)
        {
            InitializeComponent();
            _booking = booking;

            // Заполняем поля данными
            textBoxPassengerID.Text = _booking.PassengerID.ToString();
            textBoxFlightID.Text = _booking.FlightID.ToString();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            // Сохраняем изменения
            _booking.PassengerID = Convert.ToInt32(textBoxPassengerID.Text);
            _booking.FlightID = Convert.ToInt32(textBoxFlightID.Text);

            // Сохраняем изменения в базе данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("UPDATE бронирования SET номер_пассажира = @номер_пассажира, номер_рейса = @номер_рейса WHERE номер_бронирования = @номер_бронирования", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@номер_пассажира", _booking.PassengerID);
            sqlCommand.Parameters.AddWithValue("@номер_рейса", _booking.FlightID);
            sqlCommand.Parameters.AddWithValue("@номер_бронирования", _booking.BookingID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
