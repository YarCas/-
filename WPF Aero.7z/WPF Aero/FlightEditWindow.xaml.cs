﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{



    /// <summary>
    /// Логика взаимодействия для WindowEditxaml.xaml
    /// </summary>
    public partial class FlightEditWindow : Window
    {
        private Flight _flight;

        public FlightEditWindow(Flight flight)
        {
            InitializeComponent();
            _flight = flight;

            // Заполняем поля данными
            textBoxDepartureDate.Text = _flight.DepartureDate.ToString();
            textBoxArrivalDate.Text = _flight.ArrivalDate.ToString();
            textBoxDepartureAirportID.Text = _flight.DepartureAirportID.ToString();
            textBoxArrivalAirportID.Text = _flight.ArrivalAirportID.ToString();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            // Сохраняем изменения
            _flight.DepartureDate = Convert.ToDateTime(textBoxDepartureDate.Text);
            _flight.ArrivalDate = Convert.ToDateTime(textBoxArrivalDate.Text);
            _flight.DepartureAirportID = Convert.ToInt32(textBoxDepartureAirportID.Text);
            _flight.ArrivalAirportID = Convert.ToInt32(textBoxArrivalAirportID.Text);

            // Сохраняем изменения в базе данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("UPDATE рейсы SET дата_вылета = @Дата_вылета, дата_прибытия = @Дата_прибытия, аэропорт_вылета = @Аэропорт_вылета, аэропорт_прибытия = @Аэропорт_прибытия WHERE номер_рейса = @Номер_рейса", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@Дата_вылета", _flight.DepartureDate);
            sqlCommand.Parameters.AddWithValue("@Дата_прибытия", _flight.ArrivalDate);
            sqlCommand.Parameters.AddWithValue("@Аэропорт_вылета", _flight.DepartureAirportID);
            sqlCommand.Parameters.AddWithValue("@Аэропорт_прибытия", _flight.ArrivalAirportID);
            sqlCommand.Parameters.AddWithValue("@Номер_рейса", _flight.FlightID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
            }
    }
}
