﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Data.SqlClient;
using System;
using System.Windows.Controls;
using System.Net.Sockets;
using System.Windows.Media.Media3D;
using System.Windows.Documents;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Windows.Data;

namespace DataGrid
{
    public partial class MainWindow : Window
    {
        private string Role { get; set; }
        private StackPanel menuStackPanelex;

        private Dictionary<string, Type> addWindows = new Dictionary<string, Type>
{
    { "Рейсы", typeof(WindowAddFlight) },
    { "Билеты", typeof(WindowAddBooking) },
    { "Сотрудники", typeof(WindowAddxaml) },
    { "Аэропорты", typeof(WindowAddAirport) },
    { "Пассажиры", typeof(WindowAddPassenger) },
    { "Отчеты", typeof(WindowAddReport) },
    { "Пользователи", typeof(WindowAddUser) },
};


        public string connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
  
        public MainWindow(string login, string role)
        {
            InitializeComponent();
            txtLogin.Text = login;
            txtRole.Text = role;
            Role = role;
            menuStackPanelex = (StackPanel)this.FindName("menuStackPanel");
            HideMenuButtons();
            LoadReportsData();

           
                       
        }


        private void gridRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var item = dataGridRow.Item;
                if (item != null)
                {
                    MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите удалить эту строку?", "Удаление строки", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        switch (txtCurrentTable.Text)
                        {
                            case "Рейсы":
                                RemoveFlight(item);
                                break;
                            case "Билеты":
                                RemoveBooking(item);
                                break;
                            case "Сотрудники":
                                RemoveEmployee(item);
                                break;
                            case "Аэропорты":
                                RemoveAirport(item);
                                break;
                            case "Пассажиры":
                                RemovePassenger(item);
                                break;
                            case "Отчеты":
                                RemoveReport(item);
                                break;
                            case "Пользователи":
                                RemoveUser(item);
                                break;
                        }
                    }
                }
            }
        }

        private void RemoveFlight(object item)
        {
            var flight = (Flight)item;
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand($"DELETE FROM рейсы WHERE номер_рейса = @id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@id", flight.FlightID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            LoadFlightsData();
        }

        private void RemoveBooking(object item)
        {
            var booking = (Booking)item;
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand($"DELETE FROM бронирования WHERE номер_бронирования = @id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@id", booking.BookingID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            LoadTicketsData();
        }

        private void RemoveEmployee(object item)
        {
            var employee = (Employee)item;
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand($"DELETE FROM сотрудники WHERE номер_сотрудника = @id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@id", employee.EmployeeID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            LoadEmployeesData();
        }

        private void RemoveAirport(object item)
        {
            var airport = (Airport)item;
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand($"DELETE FROM аэропорты WHERE номер_аэропорта = @id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@id", airport.AirportID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            LoadAirportData();
        }

        private void RemovePassenger(object item)
        {
            var passenger = (Passenger)item;
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand($"DELETE FROM пассажиры WHERE номер_пассажира = @id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@id", passenger.PassengerID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            LoadPassengerData();
        }

        private void RemoveReport(object item)
        {
            var report = (Report)item;
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand($"DELETE FROM отчеты WHERE номер_отчета = @id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@id", report.ReportID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            LoadReportsData();
        }

        private void RemoveUser(object item)
        {
            var user = (User)item;
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand($"DELETE FROM пользователи WHERE номер_пользователя = @id", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@id", user.UserID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            LoadUserData();
        }


        private Button _selectedButton;
        private string currentTable;
        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            var addWindowType = addWindows[currentTable];
            var addWindow = (Window)Activator.CreateInstance(addWindowType);
            addWindow.ShowDialog();

            switch (currentTable)
            {
                case "Рейсы":
                    LoadFlightsData();
                    break;
                case "Билеты":
                    LoadTicketsData();
                    break;
                case "Сотрудники":
                    LoadEmployeesData();
                    break;
                case "Аэропорты":
                    LoadAirportData();
                    break;
                case "Пассажиры":
                    LoadPassengerData();
                    break;
                case "Отчеты":
                    LoadReportsData();
                    break;
                case "Пользователи":
                    LoadUserData();
                    break;
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SelectButton(sender as Button);
        }

        private void SelectButton(Button button)
        {
            if (_selectedButton != null)
            {
                _selectedButton.Background = Brushes.Transparent;
                _selectedButton.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D0C0FF"));
                _selectedButton.FontWeight = FontWeights.Normal;
            }

            button.Background = Brushes.Red; // или любой другой цвет, который вы хотите использовать
            button.Foreground = Brushes.White;
            button.FontWeight = FontWeights.Bold;
            _selectedButton = button;
        }
        private void gridEditButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var employee = dataGridRow.Item as Employee;
                if (employee != null)
                {
                    var editWindow = new WindowEditxaml(employee);
                    editWindow.ShowDialog();
                    LoadEmployeesData();
                }
            }
        }
        private void gridflEditButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var flight = dataGridRow.Item as Flight;
                if (flight != null)
                {
                    var editWindow = new FlightEditWindow(flight);
                    editWindow.ShowDialog();
                    LoadFlightsData();
                }
            }
        }

        private void gridairEditButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var airport = dataGridRow.Item as Airport;
                if (airport != null)
                {
                    var editWindow = new AirportEditWindow(airport);
                    editWindow.ShowDialog();
                    LoadAirportData();
                }
            }
        }

        private void gridpasEditButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var passenger = dataGridRow.Item as Passenger;
                if (passenger != null)
                {
                    var editWindow = new PassengerEditWindow(passenger);
                    editWindow.ShowDialog();
                    LoadPassengerData();
                }
            }
        }

        private void gridbookEditButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var booking = dataGridRow.Item as Booking;
                if (booking != null)
                {
                    var editWindow = new BookingEditWindow(booking);
                    editWindow.ShowDialog();
                    LoadTicketsData();
                }
            }
        }

        private void gridrepEditButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var report = dataGridRow.Item as Report;
                if (report != null)
                {
                    var editWindow = new ReportEditWindow(report);
                    editWindow.ShowDialog();
                    LoadReportsData();
                }
            }
        }

        private void gridusEditButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var dataGridRow = (DataGridRow)button.CommandParameter;
            if (dataGridRow != null)
            {
                var user = dataGridRow.Item as User;
                if (user != null)
                {
                    var editWindow = new UserEditWindow(user);
                    editWindow.ShowDialog();
                    LoadUserData();
                }
            }
        }

        private ObservableCollection<Employee> LoadData1()
        {
            // Загрузка данных из базы данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM сотрудники", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var employees = new ObservableCollection<Employee>();

            while (sqlDataReader.Read())
            {
                var employee = new Employee
                {
                    EmployeeID = Convert.ToInt32(sqlDataReader["номер_сотрудника"]),
                    FirstName = sqlDataReader["имя"].ToString(),
                    LastName = sqlDataReader["фамилия"].ToString(),
                    Position = sqlDataReader["должность"].ToString(),
                    AirportID = Convert.ToInt32(sqlDataReader["номер_аэропорта"])
                };

                employees.Add(employee);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            return employees;
        }

       


        private bool IsMaximize = false;
        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                if (IsMaximize)
                {
                    this.WindowState = WindowState.Normal;
                    this.Width = 1080;
                    this.Height = 720;

                    IsMaximize = false;
                }
                else
                {
                    this.WindowState = WindowState.Maximized;

                    IsMaximize = true;
                }
            }
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        private void Buttonmenu_Click(object sender, RoutedEventArgs e)
        {
            SelectButton(sender as Button);
            var button = sender as Button;
            var textBlock = button.Content as StackPanel;
            var text = (textBlock.Children[1] as TextBlock).Text;
            txtCurrentTable.Text = text;
            currentTable = text;

            switch (text)
            {
                case "Рейсы":
                    LoadFlightsData();
                    break;
                case "Билеты":
                    LoadTicketsData();
                    break;
                case "Сотрудники":
                    LoadEmployeesData();
                    break;
                case "Отчеты":
                    LoadReportsData();
                    break;
                case "Пользователи":
                    LoadUserData();
                    break;
                case "Аэропорты":
                    LoadAirportData();
                    break;
                case "Пассажиры":
                    LoadPassengerData();
                    break;
            }
        }

        private void LoadFlightsData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM рейсы", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var flights = new ObservableCollection<Flight>();

            while (sqlDataReader.Read())
            {
                var flight = new Flight
                {
                    FlightID = Convert.ToInt32(sqlDataReader["номер_рейса"]),
                    DepartureDate = Convert.ToDateTime(sqlDataReader["Дата_вылета"]),
                    ArrivalDate = Convert.ToDateTime(sqlDataReader["дата_прибытия"]),
                    DepartureAirportID = Convert.ToInt32(sqlDataReader["аэропорт_вылета"]),
                    ArrivalAirportID = Convert.ToInt32(sqlDataReader["аэропорт_прибытия"])
                };

                flights.Add(flight);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            raysDataGrid.ItemsSource = flights;
            txtRecordCount.Text = $"Количество записей: {flights.Count}";
            membersDataGrid.Visibility = Visibility.Hidden;
            ticketsDataGrid.Visibility = Visibility.Hidden;
            reportsDataGrid.Visibility = Visibility.Hidden;
            userDataGrid.Visibility = Visibility.Hidden;
            airportDataGrid.Visibility = Visibility.Hidden;
            passengerDataGrid.Visibility = Visibility.Hidden;
            raysDataGrid.Visibility = Visibility.Visible;
        }

        private void LoadPassengerData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM пассажиры", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var passengers = new ObservableCollection<Passenger>();

            while (sqlDataReader.Read())
            {
                var passenger = new Passenger
                {
                    PassengerID = Convert.ToInt32(sqlDataReader["номер_пассажира"]),
                    FirstName = sqlDataReader["имя"].ToString(),
                    LastName = sqlDataReader["фамилия"].ToString(),
                    DateOfBirth = Convert.ToDateTime(sqlDataReader["дата_рождения"])
                };

                passengers.Add(passenger);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            passengerDataGrid.ItemsSource = passengers;
            txtRecordCount.Text = $"Количество записей: {passengers.Count}";
            membersDataGrid.Visibility = Visibility.Hidden;
            ticketsDataGrid.Visibility = Visibility.Hidden;
            reportsDataGrid.Visibility = Visibility.Hidden;
            raysDataGrid.Visibility = Visibility.Hidden;
            airportDataGrid.Visibility = Visibility.Hidden;
            userDataGrid.Visibility = Visibility.Hidden;
            passengerDataGrid.Visibility = Visibility.Visible;
        }

        private void LoadAirportData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM аэропорты", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var airports = new ObservableCollection<Airport>();

            while (sqlDataReader.Read())
            {
                var airport = new Airport
                {
                    AirportID = Convert.ToInt32(sqlDataReader["номер_аэропорта"]),
                    AirportName = sqlDataReader["название_аэропорта"].ToString()
                };

                airports.Add(airport);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            airportDataGrid.ItemsSource = airports;
            txtRecordCount.Text = $"Количество записей: {airports.Count}";
            membersDataGrid.Visibility = Visibility.Hidden;
            ticketsDataGrid.Visibility = Visibility.Hidden;
            reportsDataGrid.Visibility = Visibility.Hidden;
            raysDataGrid.Visibility = Visibility.Hidden;
            userDataGrid.Visibility= Visibility.Hidden;
            passengerDataGrid.Visibility= Visibility.Hidden;
            airportDataGrid.Visibility = Visibility.Visible;
        }

        private void LoadTicketsData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM бронирования", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var tickets = new ObservableCollection<Booking>();

            while (sqlDataReader.Read())
            {
                var ticket = new Booking
                {
                    BookingID = Convert.ToInt32(sqlDataReader["номер_бронирования"]),
                    PassengerID = Convert.ToInt32(sqlDataReader["номер_пассажира"]),
                    FlightID = Convert.ToInt32(sqlDataReader["номер_рейса"])
                };

                tickets.Add(ticket);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            txtRecordCount.Text = $"Количество записей: {tickets.Count}";
            ticketsDataGrid.ItemsSource = tickets;
            membersDataGrid.Visibility = Visibility.Hidden;
            reportsDataGrid .Visibility = Visibility.Hidden;
            raysDataGrid .Visibility = Visibility.Hidden;
            userDataGrid.Visibility = Visibility.Hidden;
            airportDataGrid .Visibility = Visibility.Hidden;
            passengerDataGrid .Visibility = Visibility.Hidden;
            ticketsDataGrid.Visibility = Visibility.Visible;
        }

        private void LoadEmployeesData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM сотрудники", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var employees = new ObservableCollection<Employee>();

            while (sqlDataReader.Read())
            {
                var employee = new Employee
                {
                    EmployeeID = Convert.ToInt32(sqlDataReader["номер_сотрудника"]),
                    FirstName = sqlDataReader["имя"].ToString(),
                    LastName = sqlDataReader["фамилия"].ToString(),
                    Position = sqlDataReader["должность"].ToString(),
                    AirportID = Convert.ToInt32(sqlDataReader["номер_аэропорта"])
                };

                employees.Add(employee);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            membersDataGrid.ItemsSource = employees;
            txtRecordCount.Text = $"Количество записей: {employees.Count}";
            raysDataGrid.Visibility = Visibility.Hidden;
            reportsDataGrid.Visibility = Visibility.Hidden;
            ticketsDataGrid.Visibility = Visibility.Hidden;
            airportDataGrid.Visibility = Visibility.Hidden;
            passengerDataGrid.Visibility = Visibility.Hidden;
            userDataGrid.Visibility = Visibility.Hidden;
            membersDataGrid.Visibility = Visibility.Visible;
        }

        private void LoadReportsData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM отчеты", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var reports = new ObservableCollection<Report>();

            while (sqlDataReader.Read())
            {
                var report = new Report
                {
                    ReportID = Convert.ToInt32(sqlDataReader["номер_отчета"]),
                    CreationDate = Convert.ToDateTime(sqlDataReader["дата_создания"]),
                    ReportType = sqlDataReader["тип_отчета"].ToString(),
                    Content = sqlDataReader["содержание_отчета"].ToString(),
                    UserID = Convert.ToInt32(sqlDataReader["номер_пользователя"])
                };

                reports.Add(report);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            reportsDataGrid.ItemsSource = reports;
            txtRecordCount.Text = $"Количество записей: {reports.Count}";
            membersDataGrid.Visibility = Visibility.Hidden;
            ticketsDataGrid.Visibility = Visibility.Hidden;
            raysDataGrid.Visibility = Visibility.Hidden;
            userDataGrid.Visibility= Visibility.Hidden;
            airportDataGrid.Visibility= Visibility.Hidden;
            passengerDataGrid.Visibility= Visibility.Hidden;
            reportsDataGrid.Visibility = Visibility.Visible;
        }

        private void LoadUserData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("SELECT * FROM пользователи", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            var users = new ObservableCollection<User>();

            while (sqlDataReader.Read())
            {
                var user = new User
                {
                    UserID = Convert.ToInt32(sqlDataReader["номер_пользователя"]),
                    Login = sqlDataReader["логин"].ToString(),
                    Password = sqlDataReader["пароль"].ToString(),
                    Role = sqlDataReader["роль"].ToString()
                };

                users.Add(user);
            }

            sqlDataReader.Close();
            sqlConnection.Close();

            userDataGrid.ItemsSource = users;
            txtRecordCount.Text = $"Количество записей: {users.Count}";
            membersDataGrid.Visibility = Visibility.Hidden;
            ticketsDataGrid.Visibility = Visibility.Hidden;
            reportsDataGrid.Visibility = Visibility.Hidden;
            raysDataGrid.Visibility = Visibility.Hidden;
            airportDataGrid.Visibility = Visibility.Hidden;
            passengerDataGrid.Visibility = Visibility.Hidden;
            userDataGrid.Visibility = Visibility.Visible;
        }

       

        private void ButtonLogOut_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите выйти из программы?", "Выход", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }


        private void HideMenuButtons()
        {
            var buttons = menuStackPanelex.Children.OfType<Button>().ToList();

            switch (Role)
            {
                case "Администратор":
                    buttons.ForEach(b => b.Visibility = Visibility.Visible);
                    break;
                case "Диспетчер":
                    buttons.ForEach(b =>
                    {
                        var text = (b.Content as StackPanel).Children.OfType<TextBlock>().First().Text;
                        b.Visibility = text == "Рейсы" || text == "Отчеты" || text == "Аэропорты" ? Visibility.Visible : Visibility.Collapsed;
                    });
                    break;
                case "Билетный агент":
                    buttons.ForEach(b =>
                    {
                        var text = (b.Content as StackPanel).Children.OfType<TextBlock>().First().Text;
                        b.Visibility = text == "Билеты" || text == "Отчеты" || text == "Пассажиры" ? Visibility.Visible : Visibility.Collapsed;
                    });
                    break;
                default:
                    buttons.ForEach(b => b.Visibility = Visibility.Collapsed);
                    break;
            }
        }

        private void LoadData()
        {
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
          

         

            // Загрузка данных для сотрудников
            var sqlCommand = new SqlCommand("SELECT * FROM сотрудники", sqlConnection);
            var sqlDataReader = sqlCommand.ExecuteReader();
            ObservableCollection<Employee> employees = new ObservableCollection<Employee>();

            while (sqlDataReader.Read())
            {
                var employee = new Employee
                {
                    EmployeeID = Convert.ToInt32(sqlDataReader["номер_сотрудника"]),
                    FirstName = sqlDataReader["имя"].ToString(),
                    LastName = sqlDataReader["фамилия"].ToString(),
                    Position = sqlDataReader["должность"].ToString(),
                    AirportID = Convert.ToInt32(sqlDataReader["номер_аэропорта"])
                };

                employees.Add(employee);
            }

            sqlDataReader.Close();

            sqlConnection.Close();

            membersDataGrid.ItemsSource = employees;
            txtRecordCount.Text = $"Количество записей: {employees.Count}";
        }



}



    }

    public class Member
    {
        public string Character { get; set; }
        public Brush BgColor { get; set; }
        public string Number { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }


    public class Airport
    {
        public int AirportID { get; set; }
        public string AirportName { get; set; }
    }

    public class Flight
    {
        public int FlightID { get; set; }
        public DateTime DepartureDate { get; set; }
        public DateTime ArrivalDate { get; set; }
        public int DepartureAirportID { get; set; }
        public int ArrivalAirportID { get; set; }
    }


    public class Passenger
    {
        public int PassengerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
    }


    public class Booking
    {
        public int BookingID { get; set; }
        public int PassengerID { get; set; }
        public int FlightID { get; set; }
    }

    public class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Position { get; set; }
        public int AirportID { get; set; }
    }

    public class User
    {
        public int UserID { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }

    public class Report
    {
        public int ReportID { get; set; }
        public DateTime CreationDate { get; set; }
        public string ReportType { get; set; }
        public string Content { get; set; }
        public int UserID { get; set; }
    }



