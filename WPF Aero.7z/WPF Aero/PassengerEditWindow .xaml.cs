﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class PassengerEditWindow : Window
    {
        private Passenger _passenger;

        public PassengerEditWindow(Passenger passenger)
        {
            InitializeComponent();
            _passenger = passenger;

            // Заполняем поля данными
            textBoxFirstName.Text = _passenger.FirstName;
            textBoxLastName.Text = _passenger.LastName;
            textBoxDateOfBirth.Text = _passenger.DateOfBirth.ToString();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            // Сохраняем изменения
            _passenger.FirstName = textBoxFirstName.Text;
            _passenger.LastName = textBoxLastName.Text;
            _passenger.DateOfBirth = Convert.ToDateTime(textBoxDateOfBirth.Text);

            // Сохраняем изменения в базе данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("UPDATE пассажиры SET имя = @имя, фамилия = @фамилия, дата_рождения = @дата_рождения WHERE номер_пассажира = @номер_пассажира", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@имя", _passenger.FirstName);
            sqlCommand.Parameters.AddWithValue("@фамилия", _passenger.LastName);
            sqlCommand.Parameters.AddWithValue("@дата_рождения", _passenger.DateOfBirth);
            sqlCommand.Parameters.AddWithValue("@номер_пассажира", _passenger.PassengerID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
