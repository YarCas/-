﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class WindowAddBooking : Window
    {
        public WindowAddBooking()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            // Добавляем новую запись
            var booking = new Booking
            {
                PassengerID = Convert.ToInt32(textBoxPassengerID.Text),
                FlightID = Convert.ToInt32(textBoxFlightID.Text)
            };

            // Добавляем новую запись в базу данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("INSERT INTO бронирования (номер_пассажира, номер_рейса) VALUES (@номер_пассажира, @номер_рейса)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@номер_пассажира", booking.PassengerID);
            sqlCommand.Parameters.AddWithValue("@номер_рейса", booking.FlightID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
