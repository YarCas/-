﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class UserEditWindow : Window
    {
        private User _user;

        public UserEditWindow(User user)
        {
            InitializeComponent();
            _user = user;

            // Заполняем поля данными
            textBoxUserName.Text = _user.Login;
            textBoxPassword.Text = _user.Password;
            comboBoxRole.SelectedItem = _user.Role;
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            // Сохраняем изменения
            _user.Login = textBoxUserName.Text;
            _user.Password = textBoxPassword.Text;
            _user.Role = comboBoxRole.SelectedItem.ToString();

            // Сохраняем изменения в базе данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("UPDATE пользователи SET логин = @имя_пользователя, пароль = @пароль, роль = @роль WHERE номер_пользователя = @номер_пользователя", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@имя_пользователя", _user.Login);
            sqlCommand.Parameters.AddWithValue("@пароль", _user.Password);
            sqlCommand.Parameters.AddWithValue("@роль", ((ComboBoxItem)comboBoxRole.SelectedItem).Content.ToString());
            sqlCommand.Parameters.AddWithValue("@номер_пользователя", _user.UserID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
