﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class WindowAddPassenger : Window
    {
        public WindowAddPassenger()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            // Добавляем новую запись
            var passenger = new Passenger
            {
                FirstName = textBoxPassengerName.Text,
                LastName = textBoxPassengerLastName.Text,
                DateOfBirth = datePickerPassengerBirthDate.SelectedDate.Value
            };

            // Добавляем новую запись в базу данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("INSERT INTO пассажиры (имя, фамилия, дата_рождения) VALUES (@имя, @фамилия, @дата_рождения)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@имя", passenger.FirstName);
            sqlCommand.Parameters.AddWithValue("@фамилия", passenger.LastName);
            sqlCommand.Parameters.AddWithValue("@дата_рождения", passenger.DateOfBirth);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
