﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class ReportEditWindow : Window
    {
        private Report _report;

        public ReportEditWindow(Report report)
        {
            InitializeComponent();
            _report = report;

            // Заполняем поля данными
            textBoxCreationDate.Text = _report.CreationDate.ToString();
            textBoxReportType.Text = _report.ReportType;
            textBoxContent.Text = _report.Content;
            textBoxUserID.Text = _report.UserID.ToString();
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            // Сохраняем изменения
            _report.CreationDate = Convert.ToDateTime(textBoxCreationDate.Text);
            _report.ReportType = textBoxReportType.Text;
            _report.Content = textBoxContent.Text;
            _report.UserID = Convert.ToInt32(textBoxUserID.Text);

            // Сохраняем изменения в базе данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("UPDATE отчеты SET дата_создания = @дата_создания, тип_отчета = @тип_отчета, содержание = @содержание, номер_пользователя = @номер_пользователя WHERE номер_отчета = @номер_отчета", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@дата_создания", _report.CreationDate);
            sqlCommand.Parameters.AddWithValue("@тип_отчета", _report.ReportType);
            sqlCommand.Parameters.AddWithValue("@содержание", _report.Content);
            sqlCommand.Parameters.AddWithValue("@номер_пользователя", _report.UserID);
            sqlCommand.Parameters.AddWithValue("@номер_отчета", _report.ReportID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
