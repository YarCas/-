﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class WindowAddxaml : Window
    {
        public WindowAddxaml()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            // Добавляем новую запись
            var employee = new Employee
            {
                FirstName = textBoxFirstName.Text,
                LastName = textBoxLastName.Text,
                Position = textBoxPosition.Text,
                AirportID = Convert.ToInt32(textBoxAirportID.Text)
            };

            // Добавляем новую запись в базу данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("INSERT INTO сотрудники (имя, фамилия, должность, номер_аэропорта) VALUES (@имя, @фамилия, @должность, @номер_аэропорта)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@имя", employee.FirstName);
            sqlCommand.Parameters.AddWithValue("@фамилия", employee.LastName);
            sqlCommand.Parameters.AddWithValue("@должность", employee.Position);
            sqlCommand.Parameters.AddWithValue("@номер_аэропорта", employee.AirportID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
