﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public class TableColumn
    {
        public string Name { get; set; }
        public Type Type { get; set; }
        public string BindingPath { get; set; }
    }

    public class Table
    {
        public string Name { get; set; }
        public List<TableColumn> Columns { get; set; }
        public List<object> Rows { get; set; }
    }


    /// <summary>
    /// Логика взаимодействия для WindowEditxaml.xaml
    /// </summary>
    public partial class WindowEditxaml : Window
    {
        private Employee _employee;

        public WindowEditxaml(Employee employee)
        {
            InitializeComponent();
            _employee = employee;

            // Заполняем поля данными
            textBoxFirstName.Text = _employee.FirstName;
            textBoxLastName.Text = _employee.LastName;
            textBoxPosition.Text = _employee.Position;
            textBoxAirportID.Text = _employee.AirportID.ToString();
        }
        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            // Сохраняем изменения
            _employee.FirstName = textBoxFirstName.Text;
            _employee.LastName = textBoxLastName.Text;
            _employee.Position = textBoxPosition.Text;
            _employee.AirportID = Convert.ToInt32(textBoxAirportID.Text);

            // Сохраняем изменения в базе данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("UPDATE сотрудники SET имя = @имя, фамилия = @фамилия, должность = @должность, номер_аэропорта = @номер_аэропорта WHERE номер_сотрудника = @номер_сотрудника", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@имя", _employee.FirstName);
            sqlCommand.Parameters.AddWithValue("@фамилия", _employee.LastName);
            sqlCommand.Parameters.AddWithValue("@должность", _employee.Position);
            sqlCommand.Parameters.AddWithValue("@номер_аэропорта", _employee.AirportID);
            sqlCommand.Parameters.AddWithValue("@номер_сотрудника", _employee.EmployeeID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
