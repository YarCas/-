﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{



    /// <summary>
    /// Логика взаимодействия для WindowEditxaml.xaml
    /// </summary>
    public partial class AirportEditWindow : Window
    {
        private Airport _airport;

        public AirportEditWindow(Airport airport)
        {
            InitializeComponent();
            _airport = airport;

            // Заполняем поле данными
            textBoxAirportName.Text = _airport.AirportName;
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            // Сохраняем изменения
            _airport.AirportName = textBoxAirportName.Text;

            // Сохраняем изменения в базе данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("UPDATE аэропорты SET название_аэропорта = @название_аэропорта WHERE номер_аэропорта = @номер_аэропорта", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@название_аэропорта", _airport.AirportName);
            sqlCommand.Parameters.AddWithValue("@номер_аэропорта", _airport.AirportID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
