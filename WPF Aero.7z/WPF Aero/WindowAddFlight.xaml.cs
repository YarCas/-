﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class WindowAddFlight : Window
    {
        public WindowAddFlight()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            // Добавляем новую запись
            var flight = new Flight
            {
                DepartureDate = datePickerDepartureDate.SelectedDate.Value,
                ArrivalDate = datePickerArrivalDate.SelectedDate.Value,
                DepartureAirportID = Convert.ToInt32(textBoxDepartureAirportID.Text),
                ArrivalAirportID = Convert.ToInt32(textBoxArrivalAirportID.Text)
            };

            // Добавляем новую запись в базу данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("INSERT INTO рейсы (дата_вылета, дата_прибытия, аэропорт_вылета, аэропорт_прибытия) VALUES (@дата_вылета, @дата_прибытия, @аэропорт_вылета, @аэропорт_прибытия)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@дата_вылета", flight.DepartureDate);
            sqlCommand.Parameters.AddWithValue("@дата_прибытия", flight.ArrivalDate);
            sqlCommand.Parameters.AddWithValue("@аэропорт_вылета", flight.DepartureAirportID);
            sqlCommand.Parameters.AddWithValue("@аэропорт_прибытия", flight.ArrivalAirportID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
