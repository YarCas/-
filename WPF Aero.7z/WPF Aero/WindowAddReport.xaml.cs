﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class WindowAddReport : Window
    {
        public WindowAddReport()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            // Добавляем новую запись
            var report = new Report
            {
                CreationDate = datePickerReportCreationDate.SelectedDate.Value,
                ReportType = textBoxReportType.Text,
                Content = textBoxReportContent.Text,
                UserID = Convert.ToInt32(textBoxReportUserID.Text)
            };

            // Добавляем новую запись в базу данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("INSERT INTO отчеты (дата_создания, тип_отчета, содержание_отчета, номер_пользователя) VALUES (@дата_создания, @тип_отчета, @содержание_отчета, @номер_пользователя)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@дата_создания", report.CreationDate);
            sqlCommand.Parameters.AddWithValue("@тип_отчета", report.ReportType);
            sqlCommand.Parameters.AddWithValue("@содержание_отчета", report.Content);
            sqlCommand.Parameters.AddWithValue("@номер_пользователя", report.UserID);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
