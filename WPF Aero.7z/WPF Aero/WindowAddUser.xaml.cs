﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{

    public partial class WindowAddUser : Window
    {
        public WindowAddUser()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            // Добавляем новую запись
            var user = new User
            {
                Login = textBoxUserLogin.Text,
                Password = textBoxUserPassword.Text,
                Role = textBoxUserRole.Text
            };

            // Добавляем новую запись в базу данных
            var connectionString = "Data Source=IZMYARRK\\IZMYAR;Initial Catalog=Aerp;Integrated Security=True";
            var sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var sqlCommand = new SqlCommand("INSERT INTO пользователи (логин, пароль, роль) VALUES (@логин, @пароль, @роль)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("@логин", user.Login);
            sqlCommand.Parameters.AddWithValue("@пароль", user.Password);
            sqlCommand.Parameters.AddWithValue("@роль", user.Role);

            sqlCommand.ExecuteNonQuery();

            sqlConnection.Close();

            // Закрываем мини-окно
            Close();
        }
    }
}
