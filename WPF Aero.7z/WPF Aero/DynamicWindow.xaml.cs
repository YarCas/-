﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataGrid
{
    public partial class DynamicWindow : Window
    {
        public DynamicWindow(object data)
        {
            InitializeComponent();
            DataContext = data;
            CreateControls();
        }

        private void CreateControls()
        {
            // Получить тип данных
            Type dataType = DataContext.GetType();

            // Создать элементы управления для каждого свойства данных
            foreach (PropertyInfo property in dataType.GetProperties())
            {
                // Создать текстблок для отображения имени свойства
                TextBlock textBlock = new TextBlock();
                textBlock.Text = property.Name;
                stackPanel.Children.Add(textBlock);

                // Создать текстбокс для редактирования значения свойства
                TextBox textBox = new TextBox();
                textBox.Text = property.GetValue(DataContext).ToString();
                stackPanel.Children.Add(textBox);
            }
        }
    }
}
